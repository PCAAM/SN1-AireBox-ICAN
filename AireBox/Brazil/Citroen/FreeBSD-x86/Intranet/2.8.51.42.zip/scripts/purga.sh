#!/bin/bash

# Author: Ivan Lois
# Version: @(#)purga_ficheros v.2.8.4.3 // 28-May-2013 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

echo "*** Inicio de purga de ficheros" 									> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
date 													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

#Purga en ""$PATH_AIREBOX""/Suite_DCS/Log // Elimina archivos de acuse de envio
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/Log: "					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/*cEnvio*								>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/*cEnvio* -exec rm -rf {} \;					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/sftp_*.pid								>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/sftp_*.pid -exec rm -rf {} \;					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1


#Purga en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS // Elimina archivos con antiguedad superior a X dias


echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/DMS_OPV(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPV* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPV* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMSH(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSH* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSH* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQ(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQ* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQ(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQ* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQ(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQ* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEH(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEH* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEH* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEI(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEI* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEI* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CDEAPPRO(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPRO* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPRO* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMVNABKCMKSA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMVNABKCMKSA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMVNABKCMKSA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMPRABKCPOSA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMPRABKCPOSA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMPRABKCPOSA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMPRABKCRNSA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMPRABKCRNSA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMPRABKCRNSA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMVNABKCSDSA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMVNABKCSDSA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMVNABKCSDSA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMVNABKOA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMVNABKOA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMVNABKOA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMAAABKAR(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMAAABKAR* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMAAABKAR* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMAAABKDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMAAABKDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMAAABKDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRABKPOI(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRABKPOI* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRABKPOI* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRABKPP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRABKPP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRABKPP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRABKPR(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRABKPR* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRABKPR* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMVNABKSA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMVNABKSA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMVNABKSA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMVNABKVR(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMVNABKVR* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMVNABKVR* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMVNABKVRI(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMVNABKVRI* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMVNABKVRI* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CDEAPPROBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPROBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPROBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CDEAPPROBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPROBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPROBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMSBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMSHBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSHBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSHBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEHBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEHBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEIBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEIBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEIBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEIBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEIBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEIBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/DMS_OPVBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPVBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPVBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/DMS_OPVBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPVBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPVBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMSBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMSHBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSHBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSHBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMCOLOGSYST(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMCOLOGSYST* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMCOLOGSYST* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1