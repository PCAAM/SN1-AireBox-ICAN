#!/bin/bash

# Author: Ivan Lois (O Grove) - Equipo INDER(PSA Peugeot-Citroen)
# Version: @(#)daemon_send_AireBox_v.2.8.4.3 // 28-Sep-2012 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

NOM_ENVIO=daemon_send_AireBox

YEAR=$(date +%Y)
MONTH=$(date +%m)
DAY=$(date +%d)
HOUR=$(date +%k)
MINUTE=$(date +%M)


	# LLamadas a scripts a ejecutar

		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVPG0DDTXML.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRPL5CDESTOCKV2.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRPL5URGCDESTOCKV2.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRPL5USPOAC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRPL5SPOAC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVBQXWARAC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVBQXVHFAC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMVNLV3VROPV.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMVNLV3DMSOPV.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMVNLV3CIBLESOPV.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVBQUFI9ABSEAC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVBQGVHFFV80AC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVBQSFI9ABCHAC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRPL5CDESTOCKFP0010.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRPL5CDESTOCKFP0010B.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVBQKFI9ABDKAC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVPNRIP.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVPNRIC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMVNI03SALESV2.sh; fi