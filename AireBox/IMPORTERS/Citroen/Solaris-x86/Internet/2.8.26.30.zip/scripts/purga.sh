#!/bin/bash

# Author: Ivan Lois
# Version: @(#)purga_ficheros v.2.8.4.10 // 28-May-2013 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

echo "*** Inicio de purga de ficheros" 									> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
date 													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

#Purga en ""$PATH_AIREBOX""/Suite_DCS/Log // Elimina archivos de acuse de envio
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/Log: "					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/*cEnvio*								>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/*cEnvio* -exec rm -rf {} \;					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/sftp_*.pid								>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/sftp_*.pid -exec rm -rf {} \;					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1


#Purga en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS // Elimina archivos con antiguedad superior a X dias


echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/EDDTXML(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDTXML* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDTXML* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0053(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0059(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0059* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0059* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SIV004(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SIV004* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SIV004* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SIV005(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SIV005* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SIV005* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/C0SAG002(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C0SAG002* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C0SAG002* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/C0SAG005(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C0SAG005* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C0SAG005* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPTXML(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0006(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0006* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0006* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0093(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0093* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0093* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/PORDERGC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PORDERGC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PORDERGC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/PORDRGLC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PORDRGLC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PORDRGLC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/WCLAIMC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*WCLAIMC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*WCLAIMC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VDELIVC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VDELIVC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VDELIVC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VR_OPV.TXT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VR_OPV* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VR_OPV* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/DMS_OPV.TXT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPV* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPV* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CIBLES_OPV.TXT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CIBLES_OPV* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CIBLES_OPV* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/NY1CL3FT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NY1CL3FT* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NY1CL3FT* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/NY1CL3DD(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NY1CL3DD* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NY1CL3DD* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0079(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0079* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0079* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/PRODUITS_BPS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PRODUITS_BPS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PRODUITS_BPS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/DELIVERY_DATA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DELIVERY_DATA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DELIVERY_DATA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/FICHIER_OLIMP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*FICHIER_OLIMP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*FICHIER_OLIMP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/PARTS_SEAC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PARTS_SEAC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PARTS_SEAC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/EURECA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EURECA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EURECA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VDELIVFV80C(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VDELIVFV80C* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VDELIVFV80C* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/PARTS_CHAC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PARTS_CHAC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PARTS_CHAC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/EURECA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EURECA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EURECA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0010(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0010* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0010* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0010B(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0010B* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0010B* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG002(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0006_MULTI(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0006_MULTI* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0006_MULTI* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/PARTS_DKAC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PARTS_DKAC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PARTS_DKAC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/PACKING_INVOICING_DATA(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PACKING_INVOICING_DATA* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*PACKING_INVOICING_DATA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/pnr_Partiel(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*pnr_Partiel* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*pnr_Partiel* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/pnr_Complet(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*pnr_Complet* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*pnr_Complet* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1