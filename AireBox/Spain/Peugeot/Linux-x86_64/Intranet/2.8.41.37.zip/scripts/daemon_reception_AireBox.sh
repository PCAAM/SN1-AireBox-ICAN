#!/bin/bash

# Author: Ivan Lois (O Grove) - Equipo INDER(PSA Peugeot-Citroen)
# Version: @(#)daemon_reception_AireBox_v.2.8.19.11 // 28-Sep-2012 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

NOM_ENVIO=daemon_reception_AireBox

YEAR=$(date +%Y)
MONTH=$(date +%m)
DAY=$(date +%d)
HOUR=$(date +%k)
MINUTE=$(date +%M)


	# LLamadas a scripts a ejecutar
	
	cd ""$PATH_AIREBOX""/Suite_DCS
	if [ $HOUR -ge 00 -a $HOUR -le 24 ] ; then nohup java -Xrs -jar ""$PATH_AIREBOX""/Suite_DCS/bin/recep_DCS.jar; fi
	

	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPROPTCDEAPPRO.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPPLPRTARIFAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPPLPRTARIFAPD.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAADTSEP0093IC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMGFPFPEC100.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5LIVRAISONEXDOPR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPTARIFIAMACES.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNDVNCLIENTFINALBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNDVNPEDIDOSBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNFVNFACTURABAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPPLPRARBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPPLPRELBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPTARIFBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPTARIFDBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRECICOLIPRES.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPTARIFIAMRAES.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLIVMYCARBAP.sh_; fi