#!/bin/bash

# Author: Ivan Lois (O Grove) - Equipo INDER(PSA Peugeot-Citroen)
# Version: @(#)daemon_send_AireBox_v.2.8.2.4 // 28-Sep-2012 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

NOM_ENVIO=daemon_send_AireBox

YEAR=$(date +%Y)
MONTH=$(date +%m)
DAY=$(date +%d)
HOUR=$(date +%k)
MINUTE=$(date +%M)


	# LLamadas a scripts a ejecutar

	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVFETAPVAP.sh; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then 	sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVFETACCESOAP.sh; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then 	sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPROPTLIGFACTQ.sh; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then 	sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPROPTVENTESQ.sh; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then 	sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPROPTSTKVTEH.sh; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then 	sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPROPTSTKVTEI.sh; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then 	sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRXRELIGFACTQAP.sh; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then 	sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRXRESTKVTEHAP.sh; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then 	sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRXRESTKVTEIAP.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVFETACTPVAP.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVFETACTDIAAP.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPROPTSTOCKMQ.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMVOPTVPYDPTV03.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAVFETISCAP.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMVNLVAOPVDMSAP.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMGFPFPFC400ES.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMAADTSXP0053IC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRNFHXP0053IC.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRIDEABAP.ES.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRBVVINIT.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMPRBVVFLATFILE.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMCOLOGSYST.sh; fi
		if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_SCOMVOB2LSTCKVODMSB2L.sh; fi