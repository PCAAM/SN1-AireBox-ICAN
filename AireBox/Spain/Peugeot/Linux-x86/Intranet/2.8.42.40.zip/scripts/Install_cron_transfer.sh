#!/bin/bash

# Author: Ivan Lois
# Version: @(#)Plantilla_tareas_programadas_transfer_ARxE v.2.8.17.0 // 17-Feb-2015 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

MINUTE_TRANSFER=$((RANDOM%55+0))
if ! id -u pilote > /dev/null 2>&1; then
	USUARIO=$(who am i | awk '{print $1}')
else
	USUARIO=pilote
fi


cd ""$PATH_AIREBOX""/Suite_DCS

#transfer_AireBox - Todos los dias laborables, cada 5 horas
sudo echo "$MINUTE_TRANSFER */5 * * 1,2,3,4,5,6 $USUARIO cd ""$PATH_AIREBOX""/Suite_DCS/scripts;sh ""$PATH_AIREBOX""/Suite_DCS/scripts/daemon_transfer_AireBox.sh" >> /etc/crontab