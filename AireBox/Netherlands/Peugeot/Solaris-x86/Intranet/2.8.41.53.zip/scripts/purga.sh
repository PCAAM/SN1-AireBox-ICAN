#!/bin/bash

# Author: Ivan Lois
# Version: @(#)purga_ficheros v.2.8.17.1 // 28-Sep-2012 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

echo "*** Inicio de purga de ficheros" 									> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
date 													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

#Purga en ""$PATH_AIREBOX""/Suite_DCS/Log // Elimina archivos de acuse de envio
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/Log: "					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/*cEnvio*								>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/*cEnvio* -exec rm -rf {} \;					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1


#Purga en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS // Elimina archivos con antiguedad superior a X dias


echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMAVDTS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMAVDTS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMAVDTS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG001(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG001* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG001* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/Sales(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*Sales* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*Sales* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/NP0053(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0053* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0053* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0053IC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053IC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053IC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/EDDT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDT* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDT* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/EDDTXML(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDTXML* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDTXML* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQ(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQ* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/MAJCLT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*MAJCLT* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*MAJCLT* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEH(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEH* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEH* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEI(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEI* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEI* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQ(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQ* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQ(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQ* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG002(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG005(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG005* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG005* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/AUTOBIB(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*AUTOBIB* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*AUTOBIB* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/DIALOG(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DIALOG* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DIALOG* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/NP0093IC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0093IC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0093IC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPTXML(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG002(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPT* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPT* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPTXML(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CDEAPPRO(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPRO* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPRO* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/NP0093(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0093* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0093* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VOOPV2DMS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VOOPV2DMS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VOOPV2DMS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XQ0093(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/C400BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C400BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C400BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPSPTARIFIAMNL(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPSPTARIFIAMNL* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPSPTARIFIAMNL* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/DMS_OPV(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPV* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DMS_OPV* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPPGTARIFIAMRANL(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPPGTARIFIAMRANL* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPPGTARIFIAMRANL* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/OPV_DMSBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*OPV_DMSBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/C500BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C500BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C500BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/C100BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C100BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*C100BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/NP0093IC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0093IC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0093IC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG002(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CDEAPPRO(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPRO* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPRO* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XQ0093(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0093(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0093* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0093* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/NP0093(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0093* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*NP0093* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VOOPV2DMS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VOOPV2DMS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VOOPV2DMS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG003(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG003* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG003* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG004(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG004* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG004* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG005(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG005* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG005* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPTXML(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/AUTOBIB(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*AUTOBIB* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*AUTOBIB* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/DIALOG(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DIALOG* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*DIALOG* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPT* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPT* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPTXML(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXML* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPTARIFIAMDNL(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPTARIFIAMDNL* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPTARIFIAMDNL* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/HUB0093(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*HUB0093* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*HUB0093* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPNLPLPRTARIFMAPD(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPNLPLPRTARIFMAPD* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPNLPLPRTARIFMAPD* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1