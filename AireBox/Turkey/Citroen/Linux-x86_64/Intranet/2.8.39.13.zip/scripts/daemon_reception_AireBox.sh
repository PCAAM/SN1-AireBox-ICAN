#!/bin/bash

# Author: Ivan Lois (O Grove) - Equipo INDER(PSA Peugeot-Citroen)
# Version: @(#)daemon_reception_AireBox_v.2.8.39.13 // 28-Sep-2012 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

NOM_ENVIO=daemon_reception_AireBox

YEAR=$(date +%Y)
MONTH=$(date +%m)
DAY=$(date +%d)
HOUR=$(date +%k)
MINUTE=$(date +%M)


	# LLamadas a scripts a ejecutar
	
	cd ""$PATH_AIREBOX""/Suite_DCS
	if [ $HOUR -ge 00 -a $HOUR -le 24 ] ; then nohup java -Xrs -jar ""$PATH_AIREBOX""/Suite_DCS/bin/recep_DCS.jar; fi


	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNABKOA.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAAABKAR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAAABKDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRABKPOI.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRABKPP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRABKPR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNABKSA.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNABKVR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNABKVRI.sh_; fi