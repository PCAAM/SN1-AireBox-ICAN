#!/bin/bash

# Author: Ivan Lois (O Grove) - Equipo INDER(PSA Peugeot-Citroen)
# Version: @(#)daemon_reception_AireBox_v.2.8.25.2 // 28-Sep-2012 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

NOM_ENVIO=daemon_reception_AireBox

YEAR=$(date +%Y)
MONTH=$(date +%m)
DAY=$(date +%d)
HOUR=$(date +%k)
MINUTE=$(date +%M)


	# LLamadas a scripts a ejecutar
	
	cd ""$PATH_AIREBOX""/Suite_DCS
	if [ $HOUR -ge 00 -a $HOUR -le 24 ] ; then nohup java -Xrs -jar ""$PATH_AIREBOX""/Suite_DCS/bin/recep_DCS.jar; fi


	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPROPTCDEAPPRO.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAADTSFP0093IC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAADTSV1CDEAPPRO.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXECPTXML.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVDTSSAGAICREDIT.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVNDQFORFAITS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTXML.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMGFIP1O3CRP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRNQRBERIMAJ.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRNQROLIMP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPROPTCDEAPPRO.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5BLV2.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5BL.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5LIVRAISONEXDOPR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5PLPRTARIFMACD.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5PLPRTARIFMAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5TARIFACV2D.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5TARIFACV2.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLIVLIVRAISONS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLIVVEHICULES.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLVSOPVLIVRAISONS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLVSOPVMAJREF.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLVSOPVVEHICULES.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNPVFFACTURESAVOIRS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOSVOIVOIREFI.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOVOESTOCKVOOPV2DMS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5TARIFIAMACFR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLVSOPVLIVRAISBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLVSOPVVEHICULBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNPVFFACTAVOIRSBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLVSOPVMAJREFBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLIVLIVRAISONSBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLIVVEHICULESBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAADTSFP0093ICBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAADTSFP0093ICBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVAEFFORFAITSBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXCREDITVALBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXDEBITDETAILBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXDEBITGLOBALBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXECPTXMLBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXECPTXMLBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXTABLECODEDEFBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXTBLCODEDECISBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXTBLCODEIMPUTBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXTBLMESSAGESBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVDTSSAGAICREDITBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVDTSSAGAICREDITBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTTXTBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTTXTBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTXMLBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTXMLBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMGFIP1O3CRPBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMGFIP1O3CRPBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRAEBBAREMESBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPROPTCDEAPPROBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPROPTCDEAPPROBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5BLBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5BLV2BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5BLV2BDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5LIVREXDOPRBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5LIVREXDOPRBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPMWEDITIONPRBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPMWFACTUREPRBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNA7XGAMMETARIFVNBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNFPAGDFBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNFPAGDFBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNGT7BAMACMERGSIDBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNGT7OPCOMMERCIALBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNGT7PROSPECTSV3BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNGVESIVAUTREMVTBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNGVESIVVOCAFSBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNGVWFAUVE2BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNGVWFAUVE4BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLVXOPVMAJREFBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOSVOIVOIREBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOSVOIVOIREFIBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOVOGESTOPV2DMSBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOVOGESTVOOPV2DMSBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOSVOIVOIREBAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPTARIFIAMDFR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5MAJREFART55DBAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5MAJREFART55CBAC.sh_; fi