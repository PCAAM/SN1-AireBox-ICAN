#!/bin/bash

# Author: Ivan Lois
# Version: @(#)purga_ficheros v.2.8.25.12 // 07-Feb-2017 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

echo "*** Inicio de purga de ficheros" 									> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
date 													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

#Purga en ""$PATH_AIREBOX""/Suite_DCS/Log // Elimina archivos de acuse de envio
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/Log: "					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/*cEnvio*								>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/*cEnvio* -exec rm -rf {} \;					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/sftp_*.pid								>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/Log/sftp_*.pid -exec rm -rf {} \;					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1


#Purga en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS // Elimina archivos con antiguedad superior a X dias

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/SCOMAVFETEQCAC(+31 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/STOCKMQ(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*STOCKMQ* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*STOCKMQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/LIGFACTQ(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*LIGFACTQ* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*LIGFACTQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/STKVTEH(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*STKVTEH* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*STKVTEH* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/VENTESQ(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*VENTESQ* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*VENTESQ* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/SAG001(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*SAG001* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*SAG001* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/EDDT(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*EDDT* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*EDDT* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/CLIPREP(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*CLIPREP* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*CLIPREP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/CDEAPPRO(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*CDEAPPRO* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*CDEAPPRO* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/ACQUISTO(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*ACQUISTO* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*ACQUISTO* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/FATTURA(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*FATTURA* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*FATTURA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/VENDITA(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*VENDITA* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*VENDITA* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/LISTVN(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*LISTVN* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*LISTVN* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/BDCCDC(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*BDCCDC* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*BDCCDC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1

echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/VOOPV2DMS(+61 dias): "  		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""													>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*VOOPV2DMS* -mtime +61				>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/Suite_DCS/backup_DCS/*VOOPV2DMS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1


echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMAVDTS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMAVDTS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMAVDTS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0053IC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053IC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053IC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/IP0093IC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*IP0093IC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*IP0093IC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPL7PLPRTARIFACD(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPL7PLPRTARIFACD* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPL7PLPRTARIFACD* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPL7PLPRTARIFAC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPL7PLPRTARIFAC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPL7PLPRTARIFAC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XQ0093(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPL7PLPRTARIFMACD(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPL7PLPRTARIFMACD* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPL7PLPRTARIFMACD* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPL7PLPRTARIFMAC(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPL7PLPRTARIFMAC* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPL7PLPRTARIFMAC* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/RCOMPRPSPTARIFIAMIT(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPSPTARIFIAMIT* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*RCOMPRPSPTARIFIAMIT* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CLIPREPBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CLIPREPBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CLIPREPBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ACQUISTOBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ACQUISTOBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ACQUISTOBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/BDCCDCBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*BDCCDCBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*BDCCDCBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/FATTURABDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*FATTURABDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*FATTURABDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LISTVNBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LISTVNBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LISTVNBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENDITABDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENDITABDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENDITABDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/IP0093ICBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*IP0093ICBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*IP0093ICBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/IP0093ICBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*IP0093ICBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*IP0093ICBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPTXMLBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXMLBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXMLBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ECPTXMLBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXMLBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ECPTXMLBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG002BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG002BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG002BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CDEAPPROBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPROBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPROBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CDEAPPROBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPROBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CDEAPPROBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0093BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0093BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0093BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0093BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0093BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0093BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XQ0093BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XQ0093BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XQ0093BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/ACQUISTOBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ACQUISTOBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*ACQUISTOBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/FATTURABAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*FATTURABAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*FATTURABAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LVNPEUBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LVNPEUBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LVNPEUBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENDITABAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENDITABAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENDITABAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/BDCCDCBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*BDCCDCBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*BDCCDCBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VOOPV2DMSBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VOOPV2DMSBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VOOPV2DMSBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VOOPV2DMSBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VOOPV2DMSBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VOOPV2DMSBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMAVDTSBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMAVDTSBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMAVDTSBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SCOMAVDTSBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMAVDTSBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SCOMAVDTSBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQ_ICANV1BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQ_ICANV1BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQ_ICANV1BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQ_ICANV1BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQ_ICANV1BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQ_ICANV1BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEH_ICANV1BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEH_ICANV1BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEH_ICANV1BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEH_ICANV1BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEH_ICANV1BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEH_ICANV1BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEI_ICANV1BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEI_ICANV1BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEI_ICANV1BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEI_ICANV1BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEI_ICANV1BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEI_ICANV1BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQ_ICANV1BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQ_ICANV1BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQ_ICANV1BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQ_ICANV1BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQ_ICANV1BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQ_ICANV1BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQ_ICANV1BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQ_ICANV1BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQ_ICANV1BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQ_ICANV1BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQ_ICANV1BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQ_ICANV1BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0053ICBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053ICBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053ICBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0053ICBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053ICBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053ICBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG001BAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG001BAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG001BAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/SAG001BDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG001BDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*SAG001BDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/EDDTBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDTBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDTBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/EDDTBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDTBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*EDDTBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQTESTBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQTESTBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQTESTBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/LIGFACTQTESTBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQTESTBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*LIGFACTQTESTBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/MAJCLTBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*MAJCLTBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*MAJCLTBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/MAJCLTBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*MAJCLTBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*MAJCLTBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEHBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEHBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEHTESTBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHTESTBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHTESTBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEHTESTBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHTESTBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEHTESTBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEIBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEIBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEIBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEIBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEIBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEIBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEITESTBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEITESTBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEITESTBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STKVTEITESTBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEITESTBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STKVTEITESTBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQTESTBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQTESTBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQTESTBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/STOCKMQTESTBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQTESTBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*STOCKMQTESTBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQTESTBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQTESTBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQTESTBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/VENTESQTESTBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQTESTBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*VENTESQTESTBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0053IBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053IBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053IBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/XP0053IBDS(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053IBDS* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*XP0053IBDS* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo "*** Archivos a eliminar en ""$PATH_AIREBOX""/backup_DCS/CLIPREPBAP(+61 dias): "  	>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
echo ""												>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CLIPREPBAP* -mtime +61					>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1
find ""$PATH_AIREBOX""/backup_DCS/*CLIPREPBAP* -mtime +61 -exec rm -rf {} \;		>> ""$PATH_AIREBOX""/Suite_DCS/Log/purga_ficheros.log 2>&1