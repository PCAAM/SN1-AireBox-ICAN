#!/bin/bash

# Author: Ivan Lois (O Grove) - Equipo INDER(PSA Peugeot-Citroen)
# Version: @(#)daemon_reception_AireBox_v.2.8.5.15 // 28-Sep-2012 arce@redcitroen.com

PATH_AIREBOX=$(head ../Global_DCS.properties|grep "PATH_AIREBOX"|cut -d "=" -f2)

NOM_ENVIO=daemon_reception_AireBox

YEAR=$(date +%Y)
MONTH=$(date +%m)
DAY=$(date +%d)
HOUR=$(date +%k)
MINUTE=$(date +%M)


	# LLamadas a scripts a ejecutar
	
	cd ""$PATH_AIREBOX""/Suite_DCS
	if [ $HOUR -ge 00 -a $HOUR -le 24 ] ; then nohup java -Xrs -jar ""$PATH_AIREBOX""/Suite_DCS/bin/recep_DCS.jar; fi


	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQLSAG002.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQLSAG003.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQLSAG004.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQLSAG005.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTXML.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRTARIFZAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRTARIFZACD.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAADTSTP0093IC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGCOMANDEAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGFACTAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGTARIFAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGMVTAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGVEHICULAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRAR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPREL.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRTARIFMACD.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRTARIFMAC.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXECPTXML.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTTXT.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPROPTCDEAPPRO.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOVOESTOCKVOOPV2DMS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5LIVRAISONEXDOPR.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMGFPFPTC100.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPSPTARIFIAMPT.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGMVTBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGCMDBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGFACTBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALVEHICULBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRLDIALOGTARIFBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRECICOLIPRPT.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAADTSTP0093ICBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAADTSTP0093ICBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQLSAG002BDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQLSAG003BDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQLSAG004BDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQLSAG005BDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQWSAG002BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQWSAG003BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQWSAG004BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQWSAG005BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXECPTXMLBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVBQXECPTXMLBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVDTSSAGAICREDITBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVDTSSAGAICREDITBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTTXTBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTTXTBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTXMLBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMAVPG0ECPTXMLBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMGFPFPTC100BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMGFPFPTC100BDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPROPTCDEAPPROBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPROPTCDEAPPROBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5BLV2BAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5BLV2BDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5LIVREXDOPRBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPL5LIVREXDOPRBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRARBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRARBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRELBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRELBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRWDIALOGCMDBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRWDIALOGFACTBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNBRWDIALOGTARIFBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVNLVDOPVDMSBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOVOGESTOPV2DMSBDS.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMVOVOGESTVOOPV2DMSBAP.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRTARIFMAPD.sh_; fi
	if [ $HOUR -ge 03 -a $HOUR -le 05 ] ; then sh ""$PATH_AIREBOX""/Suite_DCS/scripts/sftp_RCOMPRPPGPLPRTARIFMAP.sh_; fi